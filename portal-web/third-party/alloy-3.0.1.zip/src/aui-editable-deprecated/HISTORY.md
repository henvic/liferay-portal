# AUI Editable Deprecated

> Documentation and test modifications are not included in this changelog. For more details, see [full commit history](https://github.com/liferay/alloy-ui/commits/master/src/aui-editable).

## @VERSION@

* [AUI-1836](https://issues.liferay.com/browse/AUI-1836) Editable portlet title does not move with portlet when window is resized or rotated
